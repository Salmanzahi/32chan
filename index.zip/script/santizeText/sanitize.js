export function sanitizeText(text) {
    if (!text) return '';
    
    // Check if this is rich text content from Quill (contains HTML)
    const isRichText = /<\/?[a-z][\s\S]*>/i.test(text);
    
    if (isRichText) {
        // This is likely rich text from the editor, use a more permissive sanitization
        return sanitizeRichText(text);
    } else {
        // This is plain text, use strict sanitization
        const div = document.createElement('div');
        div.textContent = text;
        let sanitized = div.innerHTML;
        
        // Convert newlines to <br> tags to preserve them in HTML
        sanitized = sanitized.replace(/\n/g, '<br>');
        
        return sanitized;
    }
}

/**
 * Sanitize rich text content from Quill editor
 * Preserves formatting tags while removing potentially dangerous elements
 * @param {string} html - The HTML content to sanitize
 * @returns {string} Sanitized HTML that keeps formatting but removes scripts
 */
function sanitizeRichText(html) {
    if (!html) return '';
    
    // Create a new DOMParser to parse the HTML
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    // Find and remove all script, style, iframe, and other potentially dangerous elements
    const dangerousTags = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'meta', 'link'];
    dangerousTags.forEach(tag => {
        const elements = doc.querySelectorAll(tag);
        elements.forEach(element => {
            element.parentNode.removeChild(element);
        });
    });
    
    // Remove on* attributes (onclick, onload, etc.) from all elements
    const allElements = doc.querySelectorAll('*');
    allElements.forEach(element => {
        // Get all attributes
        const attributes = element.attributes;
        const attributesToRemove = [];
        
        // Collect attributes to remove (can't modify while iterating)
        for (let i = 0; i < attributes.length; i++) {
            const attr = attributes[i];
            // Remove event handlers (on*)
            if (attr.name.toLowerCase().startsWith('on') || 
                // Remove javascript: URLs
                (attr.name === 'href' && attr.value.toLowerCase().includes('javascript:')) ||
                // Remove data: URLs which can be used for XSS
                // (attr.name === 'src' && attr.value.toLowerCase().startsWith('data:')) ||
                // Remove style attributes which can be used for XSS
                attr.name === 'style') {
                attributesToRemove.push(attr.name);
            }
        }
        
        // Remove the collected attributes
        attributesToRemove.forEach(attr => {
            element.removeAttribute(attr);
        });
    });
    
    // Get the sanitized HTML
    let sanitized = doc.body.innerHTML;
    
    // Additional replacements if needed
    sanitized = sanitized.replace(/\n/g, '<br>');
    
    return sanitized;
}