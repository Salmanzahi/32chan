export const adminRoles = {
    admins: [
        "y3FYZSmXAQV6mNdXcZ3yqXqXdC93", // Salman
        "vcfmzUKXBuQo3vQjA0n96Pqqm3D3", // Arya
        "atek34BlFTcQgTq8sMHYhLBvQUB3" // Ratol
    ]
};
