document.querySelector('footer').querySelector('p').innerHTML = 
document.querySelector('footer').querySelector('p').innerHTML.replace('2023', new Date().getFullYear());