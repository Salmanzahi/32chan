/**
 * profile.js
 * Handles user profile management functionality
 */

// Import Firebase authentication and storage from mainalt.js
import { db, storage, user } from '../../mainalt.js';
import { dbConfig } from '../../config.js';
import { isAdmin } from '../../mainalt.js';
const script = document.createElement('script');
script.src = "../../p.js"
// References to DOM elements
const profilePicture = document.getElementById('profilePicture');
const profilePictureInput = document.getElementById('profilePictureInput');
const displayNameInput = document.getElementById('displayName');
const userEmailElement = document.getElementById('userEmail');
const accountTypeElement = document.getElementById('accountType');
const memberSinceElement = document.getElementById('memberSince');
const editNameBtn = document.getElementById('editNameBtn');
const nameEditControls = document.getElementById('nameEditControls');
const saveNameBtn = document.getElementById('saveNameBtn');
const cancelNameBtn = document.getElementById('cancelNameBtn');
const saveProfileBtn = document.getElementById('saveProfileBtn');
const cancelBtn = document.getElementById('cancelBtn');

// Variables to store original values
let originalDisplayName = '';
let originalPhotoURL = '';
let profileChanged = false;
const auth = firebase.auth();

// Initialize profile page
function initProfilePage() {
    // Check if user is authenticated
    auth.onAuthStateChanged((user) => {
        if (user) {
            // Check if user is anonymous
            if (user.isAnonymous) {
                // Redirect anonymous users to home page
                window.location.href = './index.html';
                return;
            }
            // User is signed in and not anonymous, load profile data
            loadUserProfile(user);
            setupEventListeners();
        } else {
            // No user is signed in, redirect to home page
            window.location.href = './index.html';
        }
    });
}

// Load user profile data
function loadUserProfile(user) {
    console.log('Loading user profile for:', user.uid);
    
    // First check if we have a stored custom username in the database
    firebase.database().ref(`users/${user.uid}`).once('value')
        .then((snapshot) => {
            const userData = snapshot.val();
            console.log('User data from database:', userData);
            
            // Set profile picture - prioritize Google photo
            const googleProfile = user.providerData && user.providerData.find(p => p.providerId === 'google.com');
            
            if (googleProfile && googleProfile.photoURL) {
                profilePicture.src = googleProfile.photoURL;
                originalPhotoURL = googleProfile.photoURL;
            } else if (user.photoURL) {
                profilePicture.src = user.photoURL;
                originalPhotoURL = user.photoURL;
            } else {
                profilePicture.src = './images/suscat.jpg';
                originalPhotoURL = './images/suscat.jpg';
            }

            // Set display name - prioritize stored custom username over Google name
            if (userData && userData.customDisplayName) {
                // Use custom username from database if available
                console.log('Using custom username from database:', userData.customDisplayName);
                displayNameInput.value = userData.customDisplayName;
                originalDisplayName = userData.customDisplayName;
                displayNameInput.placeholder = userData.customDisplayName;
                
                // Also update the Firebase Auth display name to match the custom one
                // This ensures consistency across the app
                user.updateProfile({
                    displayName: userData.customDisplayName
                }).then(() => {
                    console.log('Updated auth profile with custom username');
                }).catch(err => {
                    console.error('Failed to update auth profile:', err);
                });
            } else if (googleProfile && googleProfile.displayName) {
                console.log('Using Google display name:', googleProfile.displayName);
                displayNameInput.value = googleProfile.displayName;
                originalDisplayName = googleProfile.displayName;
                displayNameInput.placeholder = googleProfile.displayName;
            } else if (user.displayName) {
                console.log('Using Firebase Auth display name:', user.displayName);
                displayNameInput.value = user.displayName;
                originalDisplayName = user.displayName;
                displayNameInput.placeholder = user.displayName;
            } else {
                displayNameInput.value = '';
                originalDisplayName = '';
                displayNameInput.placeholder = 'Your username';
            }

        
const db = firebase.database()
db.ref(dbConfig.messagesPath).orderByChild('userId').equalTo(user.uid).once('value')
    .then((snapshot) => {
        const postCount = snapshot.numChildren();

        // Update the DOM
        const postCountElement = document.getElementById('totalPosts');
        postCountElement.textContent = postCount;
    })
    .catch(error => {
        console.error("Error getting post count:", error);
    });

    if(isAdmin()) {
        userRole.textContent = 'Gweh Atmin Coy'
    }

            // Set email
            if (user.email) {
                userEmailElement.textContent = user.email;
            } else {
                userEmailElement.textContent = 'Anonymous account (no email)';
            }

            // Set account type
            if (user.isAnonymous) {
                accountTypeElement.textContent = 'Anonymous User';
            } else if (user.providerData && user.providerData.length > 0) {
                const provider = user.providerData[0].providerId;
                if (provider.includes('google')) {
                    accountTypeElement.textContent = 'Google Account';
                } else {
                    accountTypeElement.textContent = provider.replace('.com', '');
                }
            }

            // Set member since date
            if (user.metadata && user.metadata.creationTime) {
                const creationDate = new Date(user.metadata.creationTime);
                memberSinceElement.textContent = creationDate.toLocaleDateString();
            }
        })
        .catch(error => {
            console.error("Error loading user data:", error);
            
            // Fallback to standard profile loading
            const googleProfile = user.providerData && user.providerData.find(p => p.providerId === 'google.com');
            
            // Set profile picture
            if (googleProfile && googleProfile.photoURL) {
                profilePicture.src = googleProfile.photoURL;
                originalPhotoURL = googleProfile.photoURL;
            } else if (user.photoURL) {
                profilePicture.src = user.photoURL;
                originalPhotoURL = user.photoURL;
            } else {
                profilePicture.src = './images/suscat.jpg';
                originalPhotoURL = './images/suscat.jpg';
            }

            // Set display name
            if (googleProfile && googleProfile.displayName) {
                displayNameInput.value = googleProfile.displayName;
                originalDisplayName = googleProfile.displayName;
            } else if (user.displayName) {
                displayNameInput.value = user.displayName;
                originalDisplayName = user.displayName;
            }
        });
}

// Set up event listeners
function setupEventListeners() {
    // Profile picture change
    profilePictureInput.addEventListener('change', handleProfilePictureChange);

    // Display name edit
    editNameBtn.addEventListener('click', handleEditNameClick);
    saveNameBtn.addEventListener('click', handleSaveNameClick);
    cancelNameBtn.addEventListener('click', handleCancelNameClick);

    // Save and cancel buttons
    saveProfileBtn.addEventListener('click', handleSaveProfile);
    cancelBtn.addEventListener('click', handleCancel);
}

// Handle profile picture change
function handleProfilePictureChange(event) {
    const file = event.target.files[0];
    
    if (file) {
        // Check file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
            alert('Image is too large. Maximum size is 5MB.');
            return;
        }
        
        // Check file type
        if (!file.type.match('image.*')) {
            alert('Only image files are allowed.');
            return;
        }
        
        // Preview the image
        const reader = new FileReader();
        reader.onload = function(e) {
            profilePicture.src = e.target.result;
            profileChanged = true;
            
            // Show save buttons
            saveProfileBtn.disabled = false;
            cancelBtn.disabled = false;
        };
        reader.readAsDataURL(file);
    }
}

// Handle edit name button click
function handleEditNameClick() {
    // Make input editable
    displayNameInput.readOnly = false;
    displayNameInput.focus();
    
    // Show edit controls
    editNameBtn.style.display = 'none';
    nameEditControls.style.display = 'flex';
}

// Handle save name button click
function handleSaveNameClick() {
    // Validate username
    const newName = displayNameInput.value.trim();
    
    if (!newName) {
        alert('Username cannot be empty');
        return;
    }
    
    if (newName.length > 10) {
        alert('Username cannot be longer than 10 characters');
        return;
    }

    if (!/^[a-zA-Z0-9]+$/.test(newName)) {
        alert('Username can only contain letters and numbers');
        return;
    }
    
    // Make input readonly again
    displayNameInput.readOnly = true;
    
    // Hide edit controls
    editNameBtn.style.display = 'block';
    nameEditControls.style.display = 'none';
    
    // Mark profile as changed if the name is different
    if (newName !== originalDisplayName) {
        profileChanged = true;
        
        // Enable save button
        saveProfileBtn.disabled = false;
        
        // Update Firebase Auth profile
        const currentUser = auth.currentUser;
        if (currentUser) {
            console.log('Saving custom username:', newName);
            
            // First save to database to ensure persistence
            firebase.database().ref(`users/${currentUser.uid}`).update({
                customDisplayName: newName
            }).then(() => {
                console.log('Custom username saved to database');
                
                // Then update auth profile
                return currentUser.updateProfile({
                    displayName: newName
                });
            }).then(() => {
                console.log('Auth profile updated with custom username');
                
                // Finally update all messages
                updateUsername(currentUser.uid, newName);
                
                // Update original name to prevent duplicate updates
                originalDisplayName = newName;
                
                // Show success feedback
                const savedFeedback = document.createElement('div');
                savedFeedback.textContent = 'Username saved!';
                savedFeedback.className = 'saved-feedback';
                document.querySelector('.profile-info').appendChild(savedFeedback);
                
                // Remove feedback after 3 seconds
                setTimeout(() => {
                    savedFeedback.remove();
                }, 3000);
            }).catch(error => {
                console.error('Error updating profile:', error);
                alert('Error saving username: ' + error.message);
            });
        }
    }
}

// Handle cancel name button click
function handleCancelNameClick() {
    // Restore original name
    displayNameInput.value = originalDisplayName;
    
    // Make input readonly again
    displayNameInput.readOnly = true;
    
    // Hide edit controls
    editNameBtn.style.display = 'block';
    nameEditControls.style.display = 'none';
}

// Handle save profile button click
async function handleSaveProfile() {
    // Get the current user
    const user = auth.currentUser;
    
    if (!user) {
        alert('You must be logged in to update your profile');
        return;
    }
    
    // Show loading state
    saveProfileBtn.textContent = 'Saving...';
    saveProfileBtn.disabled = true;
    cancelBtn.disabled = true;
    
    try {
        // Check if profile picture changed
        if (profilePictureInput.files.length > 0) {
            const file = profilePictureInput.files[0];
            const storageRef = storage.ref(`profile_pictures/${user.uid}`);
            
            // Upload the file
            await storageRef.put(file);
            
            // Get the download URL
            const downloadURL = await storageRef.getDownloadURL();
            
            // Update user profile with new photo URL
            await user.updateProfile({
                photoURL: downloadURL
            });
            
            originalPhotoURL = downloadURL;
        }
        
        // Check if display name changed
        const newName = displayNameInput.value.trim();
        if (newName !== originalDisplayName) {
            // Update user profile with new display name
            await user.updateProfile({
                displayName: newName
            });
            
            // Store custom display name in Firebase database
            await firebase.database().ref(`users/${user.uid}`).update({
                customDisplayName: newName
            });
            
            // Update all user's messages with new name
            updateUsername(user.uid, newName);
            
            originalDisplayName = newName;
        }
        
        // Show success message
        alert('Profile updated successfully');
        
        // Reset profile changed flag
        profileChanged = false;
        
        // Update UI
        saveProfileBtn.textContent = 'Save Changes';
        saveProfileBtn.disabled = true;
        cancelBtn.disabled = false;
        
        // Refresh the page to show updated profile in navbar
        window.location.reload();
        
    } catch (error) {
        console.error('Error updating profile:', error);
        alert('Failed to update profile: ' + error.message);
        
        saveProfileBtn.textContent = 'Save Changes';
        saveProfileBtn.disabled = false;
        cancelBtn.disabled = false;
    }
}

// Handle cancel button click
function handleCancel() {
    if (profileChanged) {
        if (confirm('Are you sure you want to discard your changes?')) {
            // Restore original values
            displayNameInput.value = originalDisplayName;
            profilePicture.src = originalPhotoURL;
            
            // Reset profile changed flag
            profileChanged = false;
            
            // Disable save button
            saveProfileBtn.disabled = true;
        }
    } else {
        // If no changes, just go back
        window.history.back();
    }
}

// Add this function to update message usernames
function updateUsername(userId, newDisplayName) {
    const dbRef = firebase.database().ref(dbConfig.messagesPath);
    
    // Query messages by this user's ID
    dbRef.orderByChild('userId').equalTo(userId).once('value')
        .then((snapshot) => {
            if (snapshot.exists()) {
                // Create a batch update object
                const updates = {};
                
                snapshot.forEach((childSnapshot) => {
                    const messageId = childSnapshot.key;
                    updates[`${dbConfig.messagesPath}/${messageId}/userDisplayName`] = newDisplayName;
                });
                
                // Apply all updates in a single operation
                return firebase.database().ref().update(updates);
            }
        })
        .then(() => {
            console.log('All message usernames updated successfully');
        })
        .catch((error) => {
            console.error('Error updating message usernames:', error);
        });
}

// Initialize the profile page when the DOM is loaded
document.addEventListener('DOMContentLoaded', initProfilePage); 