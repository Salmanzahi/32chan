import { addChangelog } from "./createandview.js";
import { toggleChangelogVisibility } from "./visibility.js";


// Initialize visibility toggle when the module loads
// toggleChangelogVisibility();