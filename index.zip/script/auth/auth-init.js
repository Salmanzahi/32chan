/**
 * auth-init.js
 * This script handles the initialization of authentication buttons
 * after the navbar is dynamically loaded.
 */

// Import the authentication functions from mainalt.js
import { googleSignIn, anonymousSignIn, signOut } from '../../mainalt.js';

/**
 * Initialize authentication buttons by attaching event listeners
 * This function will be called after the navbar is loaded
 */
export function initAuthButtons() {
    console.log('Initializing authentication buttons');
    
    const elements = [
        { id: "googleSignInBtn", handler: googleSignIn },
        { id: "mobilegoogleSignInBtn", handler: googleSignIn },
        { id: "anonymousSignInBtn", handler: anonymousSignIn },
        { id: "mobileanonymousSignInBtn", handler: anonymousSignIn },
        { id: "signOutBtn", handler: signOut },
        { id: "mobilesignOutBtn", handler: signOut }
    ];

    elements.forEach(({ id, handler }) => {
        const el = document.getElementById(id);
        if (el) {
            // Remove any existing event listeners to prevent duplicates
            const newEl = el.cloneNode(true);
            el.parentNode.replaceChild(newEl, el);
            
            // Add the event listener
            newEl.addEventListener("click", handler);
            console.log(`Event listener attached to ${id}`);
        } else {
            console.warn(`Element with id ${id} not found.`);
        }
    });
}

/**
 * Set up a MutationObserver to detect when the navbar is loaded
 * and initialize the authentication buttons
 */
export function setupNavbarLoadListener() {
    console.log('Setting up navbar load listener');
    
    // Check if navbar container already exists and has content
    const navbarContainer = document.getElementById('navbarContainer');
    if (navbarContainer && navbarContainer.children.length > 0) {
        console.log('Navbar already loaded, initializing auth buttons');
        initAuthButtons();
        return;
    }
    
    // Set up a MutationObserver to watch for changes to the DOM
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                // Check if our navbar container has content now
                const navbarContainer = document.getElementById('navbarContainer');
                if (navbarContainer && navbarContainer.children.length > 0) {
                    console.log('Navbar loaded, initializing auth buttons');
                    initAuthButtons();
                    // Disconnect the observer once we've initialized the buttons
                    observer.disconnect();
                }
            }
        });
    });
    
    // Start observing the document body for DOM changes
    observer.observe(document.body, { childList: true, subtree: true });
}

// Initialize when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', setupNavbarLoadListener);

// Also initialize when window loads (backup)
window.addEventListener('load', setupNavbarLoadListener);