import * as inputHandling from "./inputhandling.js"
