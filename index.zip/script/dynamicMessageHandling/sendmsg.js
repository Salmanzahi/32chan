import { isAdmin, db, storage, loadUserMessages} from "../../mainalt.js";
import { dbConfig } from "../../config.js";
import { showAlert } from "../alert/alert.js";
import { getSelectedSpotifyTrack } from "../spotify/spotify.js";
import { storeImageInMongoDB } from "../../mongodb.js";

export function sendMessage() {
    const titleInput = document.getElementById('titleInput').value;
    const messageInput = document.getElementById('messageInput').value;
    const imageInput = document.getElementById('imageInput').files[0];
    const adminNameInput = document.getElementById('adminNameInput').value;
    const user = firebase.auth().currentUser;

    if (isAdmin()) {
        adminNameContainer.style.display = 'block';
    }

    if (!user) {
        showAlert("User not authenticated.", "error");
        return;
    }

    if (titleInput.trim() === '' || (messageInput.trim() === '' && !imageInput)) {
        showAlert("Title and message or image cannot be empty.", "error");
        return;
    }

    // Create a new message reference
    const newMessageRef = db.ref(dbConfig.messagesPath).push();
    const showProfile = document.getElementById('showProfileToggle').checked;
    
    // Get selected Spotify track if any
    const spotifyTrack = getSelectedSpotifyTrack();
    
    const messageData = {
        title: titleInput || null,
        text: messageInput || null,
        timestamp: Date.now(),
        userId: user.uid,
        replies: [],
        showProfile: showProfile,
        spotifyTrack: spotifyTrack
    };
    
    // Add user profile data if toggle is checked
    if (showProfile) {
        messageData.userDisplayName = user.displayName || 'Anonymous';
        messageData.userPhotoURL = user.photoURL || './images/suscat.jpg';
    }


  

    if (imageInput) {
        // Upload image to MongoDB instead of Firebase Storage
        try {
            // Show loading indicator
            console.log('Uploading image to MongoDB...');
            
            // Store the image in MongoDB
            storeImageInMongoDB(newMessageRef.key, imageInput, imageInput.name)
                .then(result => {
                    if (result.success) {
                        // Set the image URL in the message data
                        // This URL will be used to retrieve the image later
                        messageData.imageUrl = result.imageUrl;
                        
                        // Save the message data to Firebase
                        newMessageRef.set(messageData, (error) => {
                            if (error) {
                                console.error('Failed to save message:', error);
                                showAlert('Failed to save message.', 'error');
                            } else {
                                showAlert('Message sent successfully!', 'success');
                                resetForm();
                                loadUserMessages(); // Load user messages after sending a new one
                            }
                        });
                    } else {
                        console.error('Failed to upload image to MongoDB:', result.error);
                        showAlert('Failed to upload image.', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error uploading image to MongoDB:', error);
                    showAlert('Failed to upload image.', 'error');
                });
        } catch (error) {
            console.error('Exception during image upload:', error);
            showAlert('Failed to upload image.', 'error');
        }
    } else {
        newMessageRef.set(messageData, (error) => {
            if (error) {
                console.error('Failed to save message:', error);
                showAlert('Failed to save message.', 'error');
            } else {
                showAlert('Message sent successfully!', 'success');
                resetForm();
                loadUserMessages(); // Load user messages after sending a new one
            }
        });
    }
}
window.sendMessage = sendMessage;

export function resetForm() {
    const messageInput = document.getElementById('messageInput');
    const imageInput = document.getElementById('imageInput');
    const titleInput = document.getElementById('titleInput');

    if (messageInput && imageInput) {
        messageInput.value = '';
        imageInput.value = '';
        titleInput.value = '';
        
        // Clear selected Spotify track if any
        if (window.clearSelectedSpotifyTrack) {
            window.clearSelectedSpotifyTrack();
        }
    } else {
        console.error('One or more form elements not found in the DOM.');
    }
}
window.resetForm = resetForm;