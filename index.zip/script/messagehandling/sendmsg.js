import { isAdmin, db, storage, loadUserMessages} from "../../mainalt.js";
import { dbConfig } from "../../config.js";
import { showAlert } from "../alert/alert.js";
import { getSelectedSpotifyTrack } from "../spotify/spotify.js";
import { getEditorContent, clearEditorContent } from "../richtext/editor.js";


export function sendMessage() {
    const titleInput = document.getElementById('titleInput').value;
    // Get message content from the rich text editor instead of the textarea
    const messageInput = getEditorContent() || document.getElementById('messageInput').value;
    const imageInput = document.getElementById('imageInput').files[0];
    const adminNameInput = document.getElementById('adminNameInput').value;
    const user = firebase.auth().currentUser;

    if (isAdmin()) {
        adminNameContainer.style.display = 'block';
    }

    if (!user) {
        showAlert("User not authenticated.", "error");
        return;
    }

    if (titleInput.trim() === '' || (messageInput.trim() === '' && !imageInput)) {
        showAlert("Title and message or image cannot be empty.", "error");
        return;
    }

    // Get the user's custom display name from the database
    getUserCustomName(user.uid).then(customName => {
        // Create a new message reference
        const newMessageRef = db.ref(dbConfig.messagesPath).push();
        const showProfile = document.getElementById('showProfileToggle').checked;
        
        // Get selected Spotify track if any
        const spotifyTrack = getSelectedSpotifyTrack();
        
        // Use custom name if available, otherwise fall back to displayName
        const userDisplayName = customName || user.displayName || 'Anonymous';
        
        const messageData = {
            title: titleInput || null,
            text: messageInput || null,
            timestamp: Date.now(),
            userId: user.uid,
            userDisplayName: userDisplayName,
            replies: [],
            showProfile: showProfile,
            spotifyTrack: spotifyTrack
        };
        
        // Add user profile data if toggle is checked
        if (showProfile) {
            messageData.userPhotoURL = user.photoURL || './images/suscat.jpg';
        }

        if (imageInput) {
            showAlert("Image uploads are currently disabled due to database limitations. :(", "error");
            return;
        } else {
            newMessageRef.set(messageData, (error) => {
                if (error) {
                    console.error('Failed to save message:', error);
                    showAlert('Failed to save message.', 'error');
                } else {
                    showAlert('Message sent successfully!', 'success');
                    resetForm();
                    loadUserMessages(); // Load user messages after sending a new one
                }
            });
        }
    }).catch(error => {
        console.error('Error retrieving custom username:', error);
        // If there's an error getting the custom name, proceed with default displayName
        sendMessageWithDefaultName();
    });
}

// Helper function to get user's custom display name
function getUserCustomName(userId) {
    return new Promise((resolve, reject) => {
        // Reference to the user's custom display name in the database
        const userRef = firebase.database().ref(`users/${userId}/customDisplayName`);
        
        // Get the custom display name
        userRef.once('value')
            .then(snapshot => {
                const customName = snapshot.val();
                console.log('Retrieved custom name for message:', customName);
                resolve(customName);
            })
            .catch(error => {
                console.error('Error retrieving custom name:', error);
                reject(error);
            });
    });
}

// Fallback function to send message with default name
function sendMessageWithDefaultName() {
    const titleInput = document.getElementById('titleInput').value;
    const messageInput = getEditorContent() || document.getElementById('messageInput').value;
    const user = firebase.auth().currentUser;
    const showProfile = document.getElementById('showProfileToggle').checked;
    const spotifyTrack = getSelectedSpotifyTrack();
    
    // Create a new message reference
    const newMessageRef = db.ref(dbConfig.messagesPath).push();
    
    const messageData = {
        title: titleInput || null,
        text: messageInput || null,
        timestamp: Date.now(),
        userId: user.uid,
        userDisplayName: user.displayName || 'Anonymous',
        replies: [],
        showProfile: showProfile,
        spotifyTrack: spotifyTrack
    };
    
    // Add user profile data if toggle is checked
    if (showProfile) {
        messageData.userPhotoURL = user.photoURL || './images/suscat.jpg';
    }

    newMessageRef.set(messageData, (error) => {
        if (error) {
            console.error('Failed to save message:', error);
            showAlert('Failed to save message.', 'error');
        } else {
            showAlert('Message sent successfully!', 'success');
            resetForm();
            loadUserMessages();
        }
    });
}

window.sendMessage = sendMessage;

export function resetForm() {
    const messageInput = document.getElementById('messageInput');
    const imageInput = document.getElementById('imageInput');
    const titleInput = document.getElementById('titleInput');

    if (titleInput) {
        titleInput.value = '';
    }
    
    if (imageInput) {
        imageInput.value = '';
    }
    
    // Clear the rich text editor content
    clearEditorContent();
    
    // Clear selected Spotify track if any
    if (window.clearSelectedSpotifyTrack) {
        window.clearSelectedSpotifyTrack();
    }
}
window.resetForm = resetForm;